import socket
import random
import time

HEADER = 64
PORT = 5060
FORMAT = "utf-8"
DISCONNECT_MESSAGE = "!DISCONNECT"
SERVER = "192.168.0.83"
ADDR = (SERVER, PORT)

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(ADDR)

def send(msg):
    message = msg.encode(FORMAT)
    msg_length = len(message)
    send_length = str(msg_length).encode(FORMAT)
    send_length += b' '* (HEADER - len(send_length))
    client.send(send_length)
    client.send(message)
    response = client.recv(2048).decode(FORMAT)
    print(response)

i = 1
while i < 10:
    random_number = str(random.randint(1, 100))  
    send(random_number)  
    i += 1
    time.sleep(1)
    print("Waiting for next signal")

send(DISCONNECT_MESSAGE)
