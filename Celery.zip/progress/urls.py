from django.contrib import admin
from django.urls import path, include
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('example.urls')),
    path('celery-progress/', include('celery_progress.urls')),
    #path('', include('main.urls')),
]
