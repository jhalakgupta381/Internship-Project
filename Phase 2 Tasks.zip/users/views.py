from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import authenticate
from django.contrib.auth import login as auth_login
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from .forms import ProfileUpdateForm, UserUpdateForm


def register(request):
    if request.method == 'POST':
        # Extract form data from the POST request
        username = request.POST.get('name')
        email = request.POST.get('email')
        password = request.POST.get('pass')

        # Create a new user
        user = User.objects.create_user(username, email, password)
        user.save()

        # Assuming the user registration is successful, redirect to the home page
        messages.success(request, f'Your account has been created! You are now able to log in.')
        return redirect('login')
    else:
        # Render the registration form template if it's a GET request
        return render(request, 'users/register.html')

def login(request):
    if request.method == 'POST':
        username = request.POST.get('name')
        password = request.POST.get('pass')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            auth_login(request, user)
            return redirect('home')  
        else:
            return HttpResponse ("Username or Password is incorrect!!")
    return render(request, 'users/login.html')

@login_required
def logout(request):
    return render(request, 'users/logout.html')

@login_required
def profile(request):
    return render(request, 'users/profile.html')

from .forms import ProfileUpdateForm

@login_required
def update_profile(request):
    if request.method == 'POST':
        profile_form = ProfileUpdateForm(request.POST, request.FILES, instance=request.user.profile)
        user_form = UserUpdateForm(request.POST, instance=request.user)
        if profile_form.is_valid() and user_form.is_valid():
            profile_form.save()
            user_form.save()
            messages.success(request, 'Your profile has been updated!')
            return redirect('profile')
    else:
        profile_form = ProfileUpdateForm(instance=request.user.profile)
        user_form = UserUpdateForm(instance=request.user)
    context = {
        'profile_form': profile_form,
        'user_form': user_form
    }
    return render(request, 'users/update_profile.html', context)


