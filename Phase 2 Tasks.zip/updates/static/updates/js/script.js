document.addEventListener("DOMContentLoaded", function() {
    const button = document.getElementById("button");
    const colors = ["green", "red"]; // Colors for "Yes" and "No" respectively
    let index = 0;

    setInterval(() => {
        button.innerText = index === 0 ? "Yes" : "No";
        button.style.backgroundColor = colors[index];
        index = (index + 1) % 2;
    }, 5000); // Change every 5 seconds
});
