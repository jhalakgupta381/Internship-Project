# urls.py
from django.urls import path
from .views import temp

urlpatterns = [
    #path('my-view/', my_view, name='my-view'),
    path('temp/', temp, name='temp'),
    # Other URL patterns...
]
