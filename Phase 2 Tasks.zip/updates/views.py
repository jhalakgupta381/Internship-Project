from django.http import JsonResponse, HttpResponse
from django.shortcuts import render
import time


def temp(request):
    return render(request, 'updates/temp.html')



      