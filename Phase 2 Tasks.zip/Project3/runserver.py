from waitress import serve

from Project3.wsgi import application
print("Starting server...")
if __name__ == '__main__':
    serve(application, host='localhost', port='8000')