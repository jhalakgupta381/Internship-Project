from Project3.wsgi import application

def create_app():
    return application

