from flask import Flask, send_file
import csv
import random
from apscheduler.schedulers.background import BackgroundScheduler

app = Flask(__name__)

# Function to generate random data for CSV
def generate_random_data():
    return [random.randint(100, 1000) for _ in range(10)]

# Function to update CSV file with new random data
def update_csv():
    with open('chart_data.csv', 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['State', 'Confirmed', 'Recovered', 'Deaths', 'Active'])
        writer.writerow(['Andhra Pradesh'] + generate_random_data())

# Initial CSV update
update_csv()

# Create a background scheduler
scheduler = BackgroundScheduler()
scheduler.start()

# Schedule the CSV update job to run every minute
scheduler.add_job(update_csv, 'interval', minutes=1)

# Endpoint to serve the updated CSV file
@app.route('/table')
def get_data():
    return send_file('chart_data.csv')

if __name__ == '__main__':
    app.run(debug=True)
