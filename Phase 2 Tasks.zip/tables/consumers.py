import json
import asyncio
from random import randint

from channels.generic.websocket import WebsocketConsumer
from time import sleep

class ChartConsumer(WebsocketConsumer):
    def connect(self):
        self.accept()
        
        for i in range(2000):
            self.send(json.dumps({'value': randint(0,1000)}))
            sleep(1)