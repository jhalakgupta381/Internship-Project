import csv
from django.shortcuts import render

def table(request):
    csv_file_path = 'tables/chart_data.csv'  
    labels = []
    initial_data = []

    # Read data from CSV file
    with open(csv_file_path, 'r') as file:
        csv_reader = csv.reader(file)
        next(csv_reader)  # Skip the header row
        for row in csv_reader:
            labels.append(row[0])  # Assuming the first column contains labels
            initial_data.append(int(row[1]))  # Assuming the second column contains data

    context = {
        'labels': labels,
        'initial_data': initial_data,
    }
    return render(request, 'tables/table.html', context)
