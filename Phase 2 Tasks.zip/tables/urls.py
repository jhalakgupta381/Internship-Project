from django.urls import path
from .views import table
from . import views
from . import consumers

urlpatterns = [
    path('table/', table, name='table'),
]

websocket_urlpatterns = [
    path('ws/chart/', consumers.ChartConsumer.as_asgi()),
]
