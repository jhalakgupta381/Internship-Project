from django.shortcuts import render
import urllib, json

# Create your views here.
def chart(request): 
    url = "https://api.covid19india.org/data.json"
    res = urllib.request.urlopen(url)
    data = json.loads(res.read())

    labels = []
    chartdata = []
    recoveredData = []
    deathData  = []
    activeData = []

    for state in data['statewise']:
        labels.append(state['state'])
        recoveredData.append(state['recovered'])
        chartdata.append(state['confirmed'])
        deathData.append(state['deaths'])
        activeData.append(state['active'])

    context = {
        'data': data,
        'labels': labels,
        'chartdata': chartdata,
        'recoveredData': recoveredData,
        'deathData' : deathData,
        'activeData' : activeData
    }

    return render(request, 'main/chart.html', context)

def line(request): 
    url = "https://api.covid19india.org/data.json"
    res = urllib.request.urlopen(url)
    data = json.loads(res.read())

    labels = []
    chartdata = []
    recoveredData = []
    deathData  = []
    activeData = []

    for state in data['statewise']:
        labels.append(state['state'])
        recoveredData.append(state['recovered'])
        chartdata.append(state['confirmed'])
        deathData.append(state['deaths'])
        activeData.append(state['active'])

    context = {
        'data': data,
        'labels': labels,
        'chartdata': chartdata,
        'recoveredData': recoveredData,
        'deathData' : deathData,
        'activeData' : activeData
    }

    return render(request, 'main/linechart.html', context)

def bubble(request):
    url = "https://api.covid19india.org/data.json"
    res = urllib.request.urlopen(url)
    data = json.loads(res.read())

    labels = []
    chartdata = []
    recoveredData = []
    deathData  = []
    activeData = []

    for state in data['statewise']:
        labels.append(state['state'])
        recoveredData.append(state['recovered'])
        chartdata.append(state['confirmed'])
        deathData.append(state['deaths'])
        activeData.append(state['active'])

    context = {
        'data': data,
        'labels': labels,
        'chartdata': chartdata,
        'recoveredData': recoveredData,
        'deathData' : deathData,
        'activeData' : activeData
    }

    return render(request, 'main/bubble.html', context)

def doughnut(request): 
    url = "https://api.covid19india.org/data.json"
    res = urllib.request.urlopen(url)
    data = json.loads(res.read())

    labels = []
    chartdata = []
    recoveredData = []
    deathData  = []
    activeData = []

    for state in data['statewise']:
        labels.append(state['state'])
        recoveredData.append(state['recovered'])
        chartdata.append(state['confirmed'])
        deathData.append(state['deaths'])
        activeData.append(state['active'])

    context = {
        'data': data,
        'labels': labels,
        'chartdata': chartdata,
        'recoveredData': recoveredData,
        'deathData' : deathData,
        'activeData' : activeData
    }

    return render(request, 'main/doughnut.html', context)

def bubblechart(request): 
    url = "https://api.covid19india.org/data.json"
    res = urllib.request.urlopen(url)
    data = json.loads(res.read())

    labels = []
    chartdata = []
    recoveredData = []
    deathData  = []
    activeData = []
    stateData = []

    context = {
        'data': data,
        'labels': labels,
        'chartdata': chartdata,
        'stateData': stateData,
        'recoveredData': recoveredData,
        'deathData' : deathData,
        'activeData' : activeData
    }

    for state in data['statewise']:
        labels.append(state['state'])
        recoveredData.append(state['recovered'])
        chartdata.append(state['confirmed'])
        deathData.append(state['deaths'])
        activeData.append(state['active'])
        stateData.append(state['state'])

    return render(request, 'main/bubblechart.html', context)

def polararea(request): 
    url = "https://api.covid19india.org/data.json"
    res = urllib.request.urlopen(url)
    data = json.loads(res.read())

    labels = []
    chartdata = []
    recoveredData = []
    deathData  = []
    activeData = []

    for state in data['statewise']:
        labels.append(state['state'])
        recoveredData.append(state['recovered'])
        chartdata.append(state['confirmed'])
        deathData.append(state['deaths'])
        activeData.append(state['active'])

    context = {
        'data': data,
        'labels': labels,
        'chartdata': chartdata,
        'recoveredData': recoveredData,
        'deathData' : deathData,
        'activeData' : activeData
    }


    return render(request, 'main/polararea.html', context)

import csv
from django.http import HttpResponse

def download_chart_csv(request):
    labels = request.POST.getlist('labels[]')  # Get labels from POST data
    chartdata = request.POST.getlist('chartdata[]')  # Get chart data from POST data

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="chart_data.csv"'

    writer = csv.writer(response)
    writer.writerow(['Label', 'Data'])  # Write CSV header

    # Write data rows
    for label, data in zip(labels, chartdata):
        writer.writerow([label, data])

    return response
