from django.urls import path
from . import views

urlpatterns = [
    path('chart/', views.chart, name='chart'),
    path('linechart/', views.line, name='linechart'),
    path('doughnut/', views.doughnut, name='doughnut'),
    path('bubble/', views.bubble, name='bubble'),
    path('bubblechart/', views.bubblechart, name='bubblechart'),
    path('polararea/', views.polararea, name='polararea'),
]