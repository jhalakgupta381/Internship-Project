from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('covid19/' , views.covid19, name = 'covid19' )
]
