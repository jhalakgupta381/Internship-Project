from django.apps import AppConfig


class Covid19AppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'covid19app'
