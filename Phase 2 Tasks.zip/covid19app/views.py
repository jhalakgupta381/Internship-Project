from django.shortcuts import render
import requests

def covid19(request):
    # Fetch data from the API endpoint
    response = requests.get('https://api.covid19india.org/data.json')

    # Check if the request was successful (status code 200)
    if response.status_code == 200:
        # Parse JSON response
        json_data = response.json()

        # Extract country-wise summary data
        countrywise_summary_data = json_data.get('statewise', [])[1:]  # Skip the first element (header row)

        # Calculate global summary
        global_summary = {
            'active' : sum(int(data['active']) for data in countrywise_summary_data),
            'confirmed': sum(int(data['confirmed']) for data in countrywise_summary_data),
            'deaths': sum(int(data['deaths']) for data in countrywise_summary_data),
            'recovered': sum(int(data['recovered']) for data in countrywise_summary_data),
        }

        # Pass the extracted data to the template
        return render(request, 'covid19app/covid19.html', {
            'global_summary': global_summary,
            'countrywise_summary': countrywise_summary_data
        })
    else:
        # Handle the case when the API request fails
        error_message = "Failed to fetch data from the COVID-19 API."
        return render(request, 'covid19app/error.html', {'error_message': error_message})
